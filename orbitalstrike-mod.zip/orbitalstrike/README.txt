HOW TO USE
1. Go to https://fabricmc.net/develop/template and generate a project for Minecraft 26.2
   (mod id: orbitalstrike, package: com.orbitalstrike, Java 25).
2. Copy this folder's src/ into the generated project (overwrite fabric.mod.json if asked).
3. Run: ./gradlew build   -> jar is in build/libs/
4. Put the jar + Fabric API 0.154.0+26.2 in your mods folder.

COMMANDS (OP / moderator)
/orbital give <type> [players]
/orbital kit
/orbital blocks
Types: classic, nuke, carpet_bomb, lightning_storm, meteor_shower, death_ray
