package com.orbitalstrike;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import net.minecraft.ChatFormatting;
import net.minecraft.core.component.DataComponents;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.util.RandomSource;
import net.minecraft.world.entity.EntitySpawnReason;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.LightningBolt;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.item.component.CustomData;
import net.minecraft.world.item.component.ItemLore;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.levelgen.Heightmap;
import net.minecraft.world.phys.Vec3;

public final class StrikeManager {
    private static final String KEY = "orbital_type";
    private static final int CHARGE = 40; // ticks of beam before impact
    private static final List<Strike> ACTIVE = new ArrayList<>();

    private record Strike(ServerLevel level, Vec3 pos, Vec3 dir, CannonType type, int[] age) {}

    /** The 1-durability fishing rod that carries the cannon's power. */
    public static ItemStack createRod(CannonType type) {
        ItemStack s = new ItemStack(Items.FISHING_ROD);
        s.set(DataComponents.MAX_DAMAGE, 1);
        s.set(DataComponents.DAMAGE, 0);
        s.set(DataComponents.ITEM_NAME, Component.literal(type.displayName).withStyle(type.color, ChatFormatting.BOLD));
        s.set(DataComponents.LORE, new ItemLore(List.of(
            Component.literal(type.lore).withStyle(ChatFormatting.GRAY),
            Component.literal("Right-click to fire. Single use.").withStyle(ChatFormatting.DARK_GRAY))));
        s.set(DataComponents.ENCHANTMENT_GLINT_OVERRIDE, Boolean.TRUE);
        CompoundTag tag = new CompoundTag();
        tag.putString(KEY, type.id);
        s.set(DataComponents.CUSTOM_DATA, CustomData.of(tag));
        return s;
    }

    public static CannonType typeOf(ItemStack s) {
        if (!s.is(Items.FISHING_ROD)) return null;
        CustomData cd = s.get(DataComponents.CUSTOM_DATA);
        if (cd == null) return null;
        return CannonType.byId(cd.copyTag().getStringOr(KEY, ""));
    }

    public static void start(ServerLevel level, Vec3 pos, Vec3 look, CannonType type) {
        Vec3 flat = new Vec3(look.x, 0, look.z);
        Vec3 dir = flat.lengthSqr() < 1.0E-4 ? new Vec3(1, 0, 0) : flat.normalize();
        ACTIVE.add(new Strike(level, pos, dir, type, new int[] {0}));
        level.playSound(null, pos.x, pos.y, pos.z, SoundEvents.BEACON_ACTIVATE, SoundSource.PLAYERS, 8.0f, 0.6f);
    }

    public static void tick() {
        Iterator<Strike> it = ACTIVE.iterator();
        while (it.hasNext()) {
            Strike s = it.next();
            int age = ++s.age[0];
            if (age <= CHARGE) beam(s, age);
            else if (!fire(s, age - CHARGE)) it.remove();
        }
    }

    private static void beam(Strike s, int age) {
        double top = s.pos.y + 90;
        double progress = (double) age / CHARGE;
        double y = top - (top - s.pos.y) * progress;
        for (double yy = top; yy > y; yy -= 1.5) {
            s.level.sendParticles(ParticleTypes.END_ROD, s.pos.x, yy, s.pos.z, 1, 0.15, 0, 0.15, 0.0);
        }
        // targeting ring on the ground
        double r = 6 * (1 - progress) + 1;
        for (int i = 0; i < 16; i++) {
            double a = i * Math.PI / 8;
            s.level.sendParticles(ParticleTypes.ELECTRIC_SPARK,
                s.pos.x + Math.cos(a) * r, s.pos.y + 0.2, s.pos.z + Math.sin(a) * r, 1, 0, 0, 0, 0.0);
        }
    }

    /** @return true while the strike should keep running. */
    private static boolean fire(Strike s, int t) {
        ServerLevel lv = s.level;
        RandomSource rnd = lv.getRandom();
        double cx = s.pos.x, cy = s.pos.y, cz = s.pos.z;
        switch (s.type) {
            case CLASSIC -> {
                boom(lv, cx, cy, cz, 12f);
                return false;
            }
            case NUKE -> {
                if (t == 1) boom(lv, cx, cy, cz, 15f);
                if (t % 3 == 0 && t <= 40) {
                    double r = t * 1.2;
                    for (int i = 0; i < 8; i++) {
                        double a = i * Math.PI / 4 + t;
                        double x = cx + Math.cos(a) * r, z = cz + Math.sin(a) * r;
                        boom(lv, x, ground(lv, x, z), z, 5f);
                    }
                }
                return t < 40;
            }
            case CARPET -> {
                if (t % 2 == 0 && t / 2 <= 20) {
                    double x = cx + s.dir.x * (t / 2) * 5, z = cz + s.dir.z * (t / 2) * 5;
                    boom(lv, x, ground(lv, x, z), z, 4f);
                }
                return t < 40;
            }
            case STORM -> {
                double x = cx + (rnd.nextDouble() - 0.5) * 36, z = cz + (rnd.nextDouble() - 0.5) * 36;
                LightningBolt bolt = EntityType.LIGHTNING_BOLT.create(lv, EntitySpawnReason.TRIGGERED);
                if (bolt != null) {
                    bolt.setPos(x, ground(lv, x, z), z);
                    lv.addFreshEntity(bolt);
                }
                if (t % 4 == 0) boom(lv, x, ground(lv, x, z), z, 3f);
                return t < 80;
            }
            case METEOR -> {
                if (t % 4 == 0) {
                    double x = cx + (rnd.nextDouble() - 0.5) * 40, z = cz + (rnd.nextDouble() - 0.5) * 40;
                    double y = ground(lv, x, z);
                    for (double yy = y + 40; yy > y; yy -= 1.0)
                        lv.sendParticles(ParticleTypes.FLAME, x, yy, z, 2, 0.2, 0.2, 0.2, 0.01);
                    boom(lv, x, y, z, 5f);
                }
                return t < 100;
            }
            case LASER -> {
                double a = t * (2 * Math.PI / 80);
                for (double d = 2; d <= 30; d += 1.0) {
                    double x = cx + Math.cos(a) * d, z = cz + Math.sin(a) * d;
                    lv.sendParticles(ParticleTypes.SOUL_FIRE_FLAME, x, ground(lv, x, z) + 0.5, z, 1, 0.1, 0.5, 0.1, 0.0);
                }
                if (t % 4 == 0) {
                    for (double d = 3; d <= 30; d += 3) {
                        double x = cx + Math.cos(a) * d, z = cz + Math.sin(a) * d;
                        boom(lv, x, ground(lv, x, z), z, 2.5f);
                    }
                }
                return t < 80;
            }
        }
        return false;
    }

    private static void boom(ServerLevel lv, double x, double y, double z, float radius) {
        lv.explode(null, x, y, z, radius, Level.ExplosionInteraction.TNT);
        lv.sendParticles(ParticleTypes.EXPLOSION_EMITTER, x, y + 1, z, 1, 0, 0, 0, 0.0);
    }

    private static double ground(ServerLevel lv, double x, double z) {
        return lv.getHeight(Heightmap.Types.MOTION_BLOCKING, (int) Math.floor(x), (int) Math.floor(z));
    }
}
