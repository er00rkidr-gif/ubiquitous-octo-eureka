package com.orbitalstrike;

import com.mojang.brigadier.arguments.StringArgumentType;
import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.command.v2.CommandRegistrationCallback;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import net.fabricmc.fabric.api.event.player.UseItemCallback;
import net.minecraft.commands.Commands;
import net.minecraft.commands.SharedSuggestionProvider;
import net.minecraft.commands.arguments.EntityArgument;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.Identifier;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.server.permissions.Permissions;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.phys.HitResult;

public class OrbitalStrikeMod implements ModInitializer {
    public static final String MOD_ID = "orbitalstrike";

    public static Identifier id(String path) {
        return Identifier.fromNamespaceAndPath(MOD_ID, path);
    }

    @Override
    public void onInitialize() {
        ModContent.init();
        ServerTickEvents.END_SERVER_TICK.register(server -> StrikeManager.tick());

        // Right-click with a cannon rod = fire it where you're looking.
        UseItemCallback.EVENT.register((player, level, hand) -> {
            ItemStack stack = player.getItemInHand(hand);
            CannonType type = StrikeManager.typeOf(stack);
            if (type == null) return InteractionResult.PASS;
            if (!(level instanceof ServerLevel serverLevel) || !(player instanceof ServerPlayer sp)) {
                return InteractionResult.SUCCESS; // swallow the cast on the client too
            }
            HitResult hit = player.pick(300.0, 0.0f, false);
            if (hit.getType() == HitResult.Type.MISS) {
                sp.sendSystemMessage(Component.literal("No target in range."));
                return InteractionResult.FAIL;
            }
            StrikeManager.start(serverLevel, hit.getLocation(), player.getLookAngle(), type);
            stack.hurtAndBreak(1, player, hand); // 1 durability -> rod breaks
            return InteractionResult.SUCCESS;
        });

        CommandRegistrationCallback.EVENT.register((dispatcher, registryAccess, environment) ->
            dispatcher.register(Commands.literal("orbital")
                .requires(src -> src.permissions().hasPermission(Permissions.COMMANDS_MODERATOR))
                // /orbital give <type> [players]
                .then(Commands.literal("give")
                    .then(Commands.argument("type", StringArgumentType.word())
                        .suggests((c, b) -> SharedSuggestionProvider.suggest(CannonType.ids(), b))
                        .executes(c -> give(c.getSource().getPlayerOrException(),
                            StringArgumentType.getString(c, "type"), c.getSource()))
                        .then(Commands.argument("targets", EntityArgument.players())
                            .executes(c -> {
                                int n = 0;
                                for (ServerPlayer p : EntityArgument.getPlayers(c, "targets"))
                                    n += give(p, StringArgumentType.getString(c, "type"), c.getSource());
                                return n;
                            }))))
                // /orbital kit  -> one of every cannon rod
                .then(Commands.literal("kit").executes(c -> {
                    ServerPlayer p = c.getSource().getPlayerOrException();
                    for (CannonType t : CannonType.values()) give(p, StrikeManager.createRod(t));
                    c.getSource().sendSuccess(() -> Component.literal("Gave all cannon rods."), true);
                    return 1;
                }))
                // /orbital blocks -> one of every custom block
                .then(Commands.literal("blocks").executes(c -> {
                    ServerPlayer p = c.getSource().getPlayerOrException();
                    for (ItemStack s : ModContent.allBlockStacks()) give(p, s);
                    c.getSource().sendSuccess(() -> Component.literal("Gave all cannon blocks."), true);
                    return 1;
                }))));
    }

    private static int give(ServerPlayer player, String typeId, net.minecraft.commands.CommandSourceStack src) {
        CannonType type = CannonType.byId(typeId);
        if (type == null) {
            src.sendFailure(Component.literal("Unknown cannon type: " + typeId));
            return 0;
        }
        give(player, StrikeManager.createRod(type));
        src.sendSuccess(() -> Component.literal("Gave " + type.displayName + " rod to " + player.getName().getString()), true);
        return 1;
    }

    private static void give(ServerPlayer player, ItemStack stack) {
        if (!player.getInventory().add(stack)) player.drop(stack, false);
    }
}
