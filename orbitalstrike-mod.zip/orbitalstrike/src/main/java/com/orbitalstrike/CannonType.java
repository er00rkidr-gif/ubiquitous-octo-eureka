package com.orbitalstrike;

import java.util.Arrays;
import java.util.List;
import net.minecraft.ChatFormatting;

public enum CannonType {
    CLASSIC("classic", "Classic Orbital Cannon", ChatFormatting.RED, "One massive beam. One massive crater."),
    NUKE("nuke", "Nuclear Orbital Cannon", ChatFormatting.DARK_RED, "Expanding shockwave rings of destruction."),
    CARPET("carpet_bomb", "Carpet Bomb Cannon", ChatFormatting.GOLD, "A line of blasts along your line of sight."),
    STORM("lightning_storm", "Lightning Storm Cannon", ChatFormatting.AQUA, "Calls down a storm of lightning."),
    METEOR("meteor_shower", "Meteor Shower Cannon", ChatFormatting.YELLOW, "Burning meteors rain from orbit."),
    LASER("death_ray", "Death Ray Cannon", ChatFormatting.LIGHT_PURPLE, "A sweeping beam that cuts a full circle.");

    public final String id;
    public final String displayName;
    public final ChatFormatting color;
    public final String lore;

    CannonType(String id, String displayName, ChatFormatting color, String lore) {
        this.id = id; this.displayName = displayName; this.color = color; this.lore = lore;
    }

    public static CannonType byId(String id) {
        for (CannonType t : values()) if (t.id.equals(id)) return t;
        return null;
    }

    public static List<String> ids() {
        return Arrays.stream(values()).map(t -> t.id).toList();
    }
}
