package com.orbitalstrike;

import java.util.ArrayList;
import java.util.List;
import net.fabricmc.fabric.api.creativetab.v1.FabricCreativeModeTab;
import net.minecraft.core.Registry;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.core.registries.Registries;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceKey;
import net.minecraft.world.item.BlockItem;
import net.minecraft.world.item.CreativeModeTab;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.SoundType;
import net.minecraft.world.level.block.state.BlockBehaviour;

public final class ModContent {
    private static final List<Block> ALL_BLOCKS = new ArrayList<>();

    public static final Block CANNON_CORE = block("cannon_core",
        BlockBehaviour.Properties.of().strength(5f, 1200f).lightLevel(s -> 15).sound(SoundType.METAL));
    public static final Block CANNON_PLATING = block("cannon_plating",
        BlockBehaviour.Properties.of().strength(8f, 1200f).sound(SoundType.NETHERITE_BLOCK));
    public static final Block PLASMA_CONDUIT = block("plasma_conduit",
        BlockBehaviour.Properties.of().strength(4f, 1200f).lightLevel(s -> 12).sound(SoundType.GLASS));
    public static final Block TARGETING_LENS = block("targeting_lens",
        BlockBehaviour.Properties.of().strength(3f, 600f).lightLevel(s -> 8).sound(SoundType.AMETHYST));

    public static final ResourceKey<CreativeModeTab> TAB_KEY =
        ResourceKey.create(BuiltInRegistries.CREATIVE_MODE_TAB.key(), OrbitalStrikeMod.id("orbital_tab"));

    public static final CreativeModeTab TAB = FabricCreativeModeTab.builder()
        .icon(() -> StrikeManager.createRod(CannonType.NUKE))
        .title(Component.translatable("creativeTab.orbitalstrike"))
        .displayItems((params, output) -> {
            for (CannonType t : CannonType.values()) output.accept(StrikeManager.createRod(t));
            for (Block b : ALL_BLOCKS) output.accept(b);
        })
        .build();

    public static void init() {
        Registry.register(BuiltInRegistries.CREATIVE_MODE_TAB, TAB_KEY, TAB);
    }

    public static List<ItemStack> allBlockStacks() {
        List<ItemStack> out = new ArrayList<>();
        for (Block b : ALL_BLOCKS) out.add(new ItemStack(b));
        return out;
    }

    private static Block block(String name, BlockBehaviour.Properties props) {
        ResourceKey<Block> bk = ResourceKey.create(Registries.BLOCK, OrbitalStrikeMod.id(name));
        Block b = new Block(props.setId(bk));
        Registry.register(BuiltInRegistries.BLOCK, bk, b);
        ResourceKey<Item> ik = ResourceKey.create(Registries.ITEM, OrbitalStrikeMod.id(name));
        Registry.register(BuiltInRegistries.ITEM, ik,
            new BlockItem(b, new Item.Properties().setId(ik).useBlockDescriptionPrefix()));
        ALL_BLOCKS.add(b);
        return b;
    }
}
